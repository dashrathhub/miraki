<?php include('includes/header.php') ;
      include('includes/sidebar.php');

	
// $id=$_GET['id'];
?>





            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-xs-8">
							<h4 class="page-title">Leave Request</h4>
						</div>
						
					</div>
					<div class="row filter-row">
                           <div class="col-sm-3 col-md-2 col-xs-6">  
								<div class="form-group form-focus">
									<label class="control-label">Employee Name</label>
									<input type="text" class="form-control floating" />
								</div>
                           </div>
                          <!--  <div class="col-sm-3 col-md-2 col-xs-6">  
								<div class="form-group form-focus select-focus">
									<label class="control-label">Leave Type</label>
									<select class="select floating"> 
										<option value=""> -- Select -- </option>
										<option value="">Casual Leave</option>
										<option value="1">Medical Leave</option>
										<option value="1">Loss of Pay</option>
									</select>
								</div>
                           </div> -->
                         <!--   <div class="col-sm-3 col-md-2 col-xs-6"> 
								<div class="form-group form-focus select-focus">
									<label class="control-label">Leave Status</label>
									<select class="select floating"> 
										<option value=""> -- Select -- </option>
										<option value="0"> Pending </option>
										<option value="1"> Approved </option>
										<option value="2"> Rejected </option>
									</select>
								</div>
                           </div> -->
						  <!--  <div class="col-sm-3 col-md-2 col-xs-6">  
								<div class="form-group form-focus">
									<label class="control-label">From</label>
									<div class="cal-icon"><input class="form-control floating datetimepicker" type="text"></div>
								</div>
							</div>
						   <div class="col-sm-3 col-md-2 col-xs-6">  
								<div class="form-group form-focus">
									<label class="control-label">To</label>
									<div class="cal-icon"><input class="form-control floating datetimepicker" type="text"></div>
								</div>
							</div> -->
                           <div class="col-sm-3 col-md-2 col-xs-6">  
                                <a href="#" class="btn btn-success btn-block"> Search </a>  
                           </div>     
                    </div>
					<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table m-b-0 datatable">
									<thead>
										<tr>
											<th>Employee</th>
											<th>Leave Type</th>
											<th>From</th>
											<th>To</th>
											<th>No of Days/</th>
											<th>Reason</th>
											<th class="text-center">Status</th>
											<th class="text-right">Actions</th>
										</tr>
									</thead>
									<tbody>


<?php


$con=mysqli_connect('localhost','root','','leaves_data');

if($con)
{
//mysql_select_db("mic_base");
 $sql_qry="select * from leaves_tbl";
$ret=mysqli_query($con,$sql_qry);

$count=mysqli_num_rows($ret);

	if($count>0)
	while($row=mysqli_fetch_assoc($ret)){


			$leave=$row['leave_type'];

			if($leave==1){

				$in_leave=="Casual Leave";

			}

			if($leave==2)
				$in_leave="Medical Leave";
				else
				$in_leave="Sick Leave";


?>

										<tr>
											<td>
												<a class="avatar">R</a>
												<h2><a href="#"><?php echo ucwords($row['name']); ?><span>Web Developer</span></a></h2>
											</td>
											<td><?php echo "$in_leave"; ?></td>
											<td><?php echo $row['from_date'];?></td>
											<td><?php echo $row['to_date'];?></td>
											<td>hello</td>
											<td><?php echo $row['leave_reason'];?></td>
											<!-- <td>Going to Hospital</td> -->
											<div>
												<div> 
													
											<td class="text-center">
												<form method="POST" action="leave_action.php" >
												<div class="dropdown action-label">
													<input type="hidden" name="hidden_id" value="<?php echo $row['leave_id'];?>" >



													<!-- <a class="btn btn-white btn-sm rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false">
														<i class="fa fa-dot-circle-o text-purple"></i> New <i class="caret"></i>
													</a> -->
												
													<!-- <label>Leave Type <span class="text-danger">*</span></label> -->
													<select name="leaveaction" class="leaveaction" id="<?php echo $row['leave_id'];?>">
													    <!-- <ul class="dropdown-menu pull-right"> -->
														
														<option value="1" <?php if($row['leave_status']=='1') echo "selected";?>> <li><a href="#"<i class="fa fa-dot-circle-o text-success"></i> Approved</a></li></option>

														<option value="0"  <?php if($row['leave_status']=='0') echo "selected";?>><li><a href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a></li></option>

														<option value="2"  <?php if($row['leave_status']=='2') echo "selected";?>><li><a href="#"><i class="fa fa-dot-circle-o text-danger"></i> Declined</a></li></option>
													<!-- </ul> -->
													</select>

												</div>
												<!-- <input type="submit" name="submit"> -->
											
												</form>
											</td>
											
											<td class="text-right">
												<div class="dropdown">
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu pull-right">
														<!-- <li><a href="#" title="Edit" data-toggle="modal" data-target="#edit_leave"><i class="fa fa-pencil m-r-5"></i> Edit</a></li> -->
														<li><a href="delete.php?leave_id=<?php echo $row['leave_id'];?>" title="Decline" data-toggle="modal" data-target="#delete_approve"><i class="fa fa-trash-o m-r-5"></i> Delete</a></li>
														<!-- <li><a name="submit" href="leave_action.php?leave_id=<?php //echo $row['leave_id'];?>">Submit</a></li> -->
													</ul>
												</div>
												
											</td>
												
											</div>
										</tr>

	<?php
}
}
    ?>

			
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
            </div>



<!-- 
										<tr>
											<td>
												<a class="avatar">R</a>
												<h2><a href="#">Richard Miles <span>Web Developer</span></a></h2>
											</td>
											<td>Casual Leave</td>
											<td>8 Aug 2017</td>
											<td>8 Aug 2017</td>
											<td>2 days</td>
											<td>Going to Hospital</td>
											<td class="text-center">
												<div class="dropdown action-label">
													<a class="btn btn-white btn-sm rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false">
														<i class="fa fa-dot-circle-o text-purple"></i> New <i class="caret"></i>
													</a>
													<ul class="dropdown-menu pull-right">
														<li><a href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a></li>
														<li><a href="#"><i class="fa fa-dot-circle-o text-success"></i> Approved</a></li>
														<li><a href="#"><i class="fa fa-dot-circle-o text-danger"></i> Declined</a></li>
													</ul>
												</div>
											</td>
											<td class="text-right">
												<div class="dropdown">
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu pull-right">
														<li><a href="#" title="Edit" data-toggle="modal" data-target="#edit_leave"><i class="fa fa-pencil m-r-5"></i> Edit</a></li>
														<li><a href="#" title="Decline" data-toggle="modal" data-target="#delete_approve"><i class="fa fa-trash-o m-r-5"></i> Delete</a></li>
													</ul>
												</div>
											</td>
										</tr>


										<tr>
											<td>
												<a class="avatar">R</a>
												<h2><a href="#">Richard Miles <span>Web Developer</span></a></h2>
											</td>
											<td>Casual Leave</td>
											<td>8 Aug 2017</td>
											<td>8 Aug 2017</td>
											<td>2 days</td>
											<td>Going to Hospital</td>
											<td class="text-center">
												<div class="dropdown action-label">
													<a class="btn btn-white btn-sm rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false">
														<i class="fa fa-dot-circle-o text-purple"></i> New <i class="caret"></i>
													</a>
													<ul class="dropdown-menu pull-right">
														<li><a href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a></li>
														<li><a href="#"><i class="fa fa-dot-circle-o text-success"></i> Approved</a></li>
														<li><a href="#"><i class="fa fa-dot-circle-o text-danger"></i> Declined</a></li>
													</ul>
												</div>
											</td>
											<td class="text-right">
												<div class="dropdown">
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu pull-right">
														<li><a href="#" title="Edit" data-toggle="modal" data-target="#edit_leave"><i class="fa fa-pencil m-r-5"></i> Edit</a></li>
														<li><a href="#" title="Decline" data-toggle="modal" data-target="#delete_approve"><i class="fa fa-trash-o m-r-5"></i> Delete</a></li>
													</ul>
												</div>
											</td>
										</tr> -->
										
							<!-- 			
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
            </div>
 -->
				


          
			<div id="delete_approve" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Decline Leave Request</h4>
						</div>
						<form>
							<div class="modal-body card-box">
								<p>Are you sure want to declined this leave request?</p>
								<div class="m-t-20 text-left">
									<a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
									<button type="submit" class="btn btn-danger">Decline</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div id="approve_leave" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Approve for Leave</h4>
						</div>
						<form>
							<div class="modal-body card-box">
								<p>Are you sure want to approve for this leave request?</p>
								<div class="m-t-20 text-left">
									<a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
									<button type="submit" class="btn btn-info">Approve</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			
			<!-- <div id="edit_leave" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Edit Leave</h4>
						</div>
						<div class="modal-body">
							<form>
								<div class="form-group">
									<label>Leave Type <span class="text-danger">*</span></label>
									<select class="select">
										<option value="">Select Leave Type</option>
										<option value="">Casual Leave 12 Days</option>
									</select>
								</div>
								<div class="form-group">
									<label>From <span class="text-danger">*</span></label>
									<div class="cal-icon"><input class="form-control datetimepicker" value="01-01-2017" type="text"></div>
								</div>
								<div class="form-group">
									<label>To <span class="text-danger">*</span></label>
									<div class="cal-icon"><input class="form-control datetimepicker" value="01-01-2017" type="text"></div>
								</div>
								<div class="form-group">
									<label>Number of days <span class="text-danger">*</span></label>
									<input class="form-control" readonly="" type="text" value="2">
								</div>
								<div class="form-group">
									<label>Remaining Leaves <span class="text-danger">*</span></label>
									<input class="form-control" readonly="" value="12" type="text">
								</div>
								<div class="form-group">
									<label>Leave Reason <span class="text-danger">*</span></label>
									<textarea rows="4" cols="5" class="form-control">Going to hospital</textarea>
								</div>
								<div class="m-t-20 text-center">
									<button class="btn btn-primary">Save Changes</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div> -->
        </div>
		<div class="sidebar-overlay" data-reff="#sidebar"></div>
        <script type="text/javascript" src="assets/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="assets/js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="assets/js/dataTables.bootstrap.min.js"></script>
		<script type="text/javascript" src="assets/js/jquery.slimscroll.js"></script>
		<script type="text/javascript" src="assets/js/select2.min.js"></script>
		<script type="text/javascript" src="assets/js/moment.min.js"></script>
		<script type="text/javascript" src="assets/js/bootstrap-datetimepicker.min.js"></script>
		<script type="text/javascript" src="assets/js/app.js"></script>
    </body>
    <script>

$(function(){
	$('.leaveaction').change(function(){
		var str="update_status=1&state="+$(this).val()+"&id="+$(this).attr('id');
		$.ajax({
			type: "POST",
			url: "leave_action.php",
			cache: false,
			data: str,
			success: function(result){
				if(result==1) alert("Status Updated..."); else alert("Status Updation Failed...");
				//alert(result);
				

			}
		});

	});	
});
</script>

<!-- Mirrored from dreamguys.co.in/smarthr/maroon/leaves.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 10 Dec 2018 10:11:20 GMT -->
</html>