<?php
$conn=mysqli_connect("localhost","root","","leaves_data");
// echo $l_id=$_POST['hidden_id'];

//print_r($_POST);
if(isset($_POST['update_status'])){
	$sql_qry="update leaves_tbl set leave_status='".$_POST['state']."' where leave_id=".$_POST['id'];
	$update=mysqli_query($conn,$sql_qry);
	if($update) echo "1"; else echo "0";
}

// $l_status=$_GET['leave_status'];

// $conn=mysqli_connect("localhost","root","","leaves_data");

// if($l_status==0){
// 	$leave_status="Pending leave";
// }

// if($l_status==1){
// 	$leave_status="Approve leave";
// }

// if($l_status==2){
// 	$leave_status="Decline leave";
// }





// $sql_qry="update leave_tbl set leave_status='$leave_status' where leave_id='$l_id' ";




?>