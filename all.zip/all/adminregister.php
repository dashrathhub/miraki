<?php
//extract($_POST);
if(isset($_POST['submit'])){

$con=mysqli_connect('localhost','root','','leaves_data');

$eid=$_POST['eid'];
$name=$_POST['name'];
$email=$_POST['email'];

$password=$_POST['password'];

if(!empty($name) && !empty($email))
{
$sql_qry="insert into admin (eid,username,email,password) values ('$eid','$name','$email','$password')";

$ret=mysqli_query($con,$sql_qry);
if($ret){
echo "Your Registration successfull";
// header('location:display.php');
}
else
echo "NO Register";
}else
echo "Fill form field";
}
?>
<form method="post" action="">
	Eid:<input type="text" name="eid">
Name:<input type="text" name="name">
Email:<input type="text" name="email"><br/><br/>
Password:<input type="password" name="password"><br/><br/>
Submit:<input type="submit" name="submit">

</form>