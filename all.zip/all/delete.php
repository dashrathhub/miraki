<?php

$con=mysqli_connect('localhost','root','','leaves_data');


$leave_id=$_GET['leave_id'];

$uid=$_GET['id'];

if(!empty($uid=$_GET['id'])){

$sql_del="delete from employee_tbl where id='$uid'";
$resp=mysqli_query($con,$sql_del);
if($resp){
header('location:leaves.php');

}else
echo "Record not deleted";
}




if(!empty($leave_id=$_GET['leave_id'])){

$sql_del="delete from leaves_tbl where leave_id='$leave_id'";
$resp=mysqli_query($con,$sql_del);
if($resp){
header('location:index.php');

}else
echo "Record not deleted";
}



?>
