<!-- 
<?php/*
if(isset($_POST['submit'])){
$name=$_POST['name'];
// $email=$_POST['email'];
// $mobile=$_POST['mobile'];
// $password=$_POST['password'];
$con=mysqli_connect('localhost','root','','mic_base');

if(!empty($name))
{
// mysql_select_db("mic_base");

$sql_qry="select name,email,mobile,password from mic_tbl where name='$name' ";
$ret=mysqli_query($con,$sql_qry);

$count=mysqli_num_rows($ret);

	if($count>0){
	session_start();

$row=mysqli_fetch_assoc($ret);
print_r($row);
// exit;
	echo $_SESSION['name']=$row['name'] ;
	echo $_SESSION['email']=$row['email'];
	echo $_SESSION['mobile']=$row['mobile'] ;
	echo $_SESSION['password']=$row['password'] ;
}

}
else
echo "Sorry..!No Result Not Found";

}*/

?>

<form method="post" action="" >
	<input type="text" name="name">
	<input type="submit" name="submit">

</form>
<a href="logout.php">Logout</a>
 -->

<?php

echo "hello";


?>
